import { useState } from 'react';
import { MessageCircle, X, ArrowRight } from 'lucide-react';

// Número do WhatsApp do Grupo Infoco / Iuptec
// ALTERE para o número real antes do deploy
const WHATSAPP_NUMBER = '5534999999999';
const WHATSAPP_MESSAGE = 'Olá! Vim pelo site da Iuptec e gostaria de saber mais sobre as soluções de IA.';

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);

  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`;

  return (
    <>
      {/* Botão flutuante */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label={isOpen ? 'Fechar menu de contato' : 'Abrir menu de contato'}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-iuptec-teal shadow-lg shadow-iuptec-teal/30 flex items-center justify-center hover:scale-105 transition-all duration-200"
      >
        {isOpen
          ? <X className="w-5 h-5 text-dark-950" />
          : <MessageCircle className="w-5 h-5 text-dark-950" />
        }
      </button>

      {/* Painel */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-72 bg-dark-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden">

          {/* Header */}
          <div className="px-5 py-4 border-b border-white/10">
            <p className="font-bold text-white text-sm">Fale com a Iuptec</p>
            <p className="text-white/40 text-xs mt-0.5">Resposta rápida pela equipe</p>
          </div>

          {/* Opções */}
          <div className="p-4 space-y-3">

            {/* WhatsApp direto */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 rounded-xl bg-[#25D366]/10 border border-[#25D366]/20 hover:border-[#25D366]/50 transition-all group"
            >
              {/* Ícone WhatsApp SVG */}
              <div className="w-9 h-9 rounded-lg bg-[#25D366] flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-white text-sm font-semibold">WhatsApp</p>
                <p className="text-white/40 text-xs">Resposta em minutos</p>
              </div>
              <ArrowRight className="w-4 h-4 text-white/30 group-hover:text-[#25D366] transition-colors" />
            </a>

            {/* Qualificação conversacional */}
            <a
              href="/qualificacao"
              className="flex items-center gap-4 p-4 rounded-xl bg-iuptec-teal/10 border border-iuptec-teal/20 hover:border-iuptec-teal/50 transition-all group"
            >
              <div className="w-9 h-9 rounded-lg bg-iuptec-teal/20 border border-iuptec-teal/30 flex items-center justify-center flex-shrink-0">
                <MessageCircle className="w-5 h-5 text-iuptec-teal" />
              </div>
              <div className="flex-1">
                <p className="text-white text-sm font-semibold">Diagnóstico gratuito</p>
                <p className="text-white/40 text-xs">Responda 5 perguntas e receba uma análise</p>
              </div>
              <ArrowRight className="w-4 h-4 text-white/30 group-hover:text-iuptec-teal transition-colors" />
            </a>

          </div>

          {/* Footer */}
          <div className="px-5 py-3 border-t border-white/5">
            <p className="text-white/25 text-xs text-center">
              Iuptec · Grupo Infoco
            </p>
          </div>

        </div>
      )}
    </>
  );
}
