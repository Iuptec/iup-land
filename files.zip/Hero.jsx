import Button from "./ui/Button";

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center pt-20 relative overflow-hidden bg-dark-950">

      {/* Fundo: gradiente sutil, sem neon */}
      <div className="absolute inset-0 bg-gradient-to-br from-dark-900 via-dark-950 to-dark-900 pointer-events-none" />
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-iuptec-teal/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-iuptec-orange/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10 py-24">

        {/* Tag do Grupo */}
        <div className="mb-10">
          <span className="inline-block text-xs font-semibold tracking-widest text-iuptec-teal uppercase border border-iuptec-teal/30 px-4 py-1.5 rounded-full bg-iuptec-teal/5">
            Grupo Infoco · Empresa de Tecnologia com IA
          </span>
        </div>

        {/* Headline principal */}
        <div className="max-w-4xl mb-8">
          <h1 className="text-5xl lg:text-7xl font-black leading-[1.05] tracking-tight text-white">
            Construímos sistemas que fazem{" "}
            <span className="text-iuptec-teal">empresas operarem</span>{" "}
            diferente.
          </h1>
        </div>

        {/* Subtítulo */}
        <p className="text-lg lg:text-xl text-white/60 max-w-2xl mb-12 leading-relaxed">
          Da automação inteligente à arquitetura AI-First — entregamos
          soluções que transformam como negócios competem e escalam.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 mb-24">
          <Button variant="animated">
            Falar com a equipe →
          </Button>
          <Button variant="sparkle">
            Ver nosso trabalho
          </Button>
        </div>

        {/* Divisor */}
        <div className="border-t border-white/10 pt-16">

          {/* Fundadores */}
          <p className="text-xs font-semibold tracking-widest text-white/30 uppercase mb-10">
            Fundadores
          </p>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl">

            {/* Geraldo */}
            <div className="flex items-start gap-5">
              <div className="flex-shrink-0">
                <img
                  src="/geraldo.png"
                  alt="Geraldo Oliveira"
                  className="w-16 h-16 rounded-2xl object-cover object-top grayscale-[20%]"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                {/* Fallback */}
                <div
                  style={{ display: 'none' }}
                  className="w-16 h-16 rounded-2xl bg-dark-800 border border-white/10 flex items-center justify-center text-white/30 text-xl font-bold"
                >
                  G
                </div>
              </div>
              <div>
                <p className="font-bold text-white text-base">Geraldo Oliveira</p>
                <p className="text-iuptec-orange text-sm font-medium mb-2">Co-Founder · Estratégia & Negócios</p>
                <p className="text-white/50 text-sm leading-relaxed">
                  35+ anos empreendendo. Mais de 200 negócios estruturados.
                  Visão comercial e de produto que conecta tecnologia a resultados reais.
                </p>
              </div>
            </div>

            {/* Diego */}
            <div className="flex items-start gap-5">
              <div className="flex-shrink-0">
                <img
                  src="/diego.png"
                  alt="Diego Dias"
                  className="w-16 h-16 rounded-2xl object-cover object-top grayscale-[20%]"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                {/* Fallback */}
                <div
                  style={{ display: 'none' }}
                  className="w-16 h-16 rounded-2xl bg-dark-800 border border-white/10 flex items-center justify-center text-white/30 text-xl font-bold"
                >
                  D
                </div>
              </div>
              <div>
                <p className="font-bold text-white text-base">Diego Dias</p>
                <p className="text-iuptec-teal text-sm font-medium mb-2">Co-Founder · CTO · Mestrando em IA / UFU</p>
                <p className="text-white/50 text-sm leading-relaxed">
                  14+ anos entregando soluções tecnológicas de alto impacto.
                  Arquiteto de sistemas sustentáveis que transformam como empresas operam em um mundo AI-First.
                </p>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
